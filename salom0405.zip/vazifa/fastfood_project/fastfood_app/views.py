from django.shortcuts import render, get_object_or_404, redirect
from .models import FoodType, Food
from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.views.generic import CreateView, UpdateView, DeleteView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.http import HttpResponse
from django.conf import settings
import os
from django.contrib import messages


@permission_required('fastfood_app.add_food')
def add_food(request):
    if request.method == "POST":
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Taom muvaffaqiyatli qo\'shildi!')
            return redirect('home')
    else:
        form = FoodForm()
    return render(request, 'fastfood_app/add_food.html', {'form': form})


def media(request, path):
    # Media fayllarini qaytarish
    file_path = os.path.join(settings.MEDIA_ROOT, path)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            return HttpResponse(file.read(), content_type='application/octet-stream')
    else:
        return HttpResponse(status=404)


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


# Barcha taom turlari va taomlarni ko'rsatish uchun
def home(request):
    food_types = FoodType.objects.all()
    foods = Food.objects.all()
    return render(request, 'fastfood_app/home.html', {'food_types': food_types, 'foods': foods})


# Taomni ko'rish va ko'rishlar sonini oshirish uchun
def food_detail(request, pk):
    food = get_object_or_404(Food, pk=pk)
    food.korishlar_soni += 1  # Apostrof o'rniga "korishlar_soni" ishlatamiz
    food.save()
    return render(request, 'fastfood_app/food_detail.html', {'food': food})


# Taom qo'shish
@permission_required('fastfood_app.add_food')
def add_food(request):
    if request.method == "POST":
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = FoodForm()
    return render(request, 'fastfood_app/add_food.html', {'form': form})


# Taomni o'zgartirish
@permission_required('fastfood_app.change_food')
def update_food(request, pk):
    food = get_object_or_404(Food, pk=pk)
    if request.method == "POST":
        form = FoodForm(request.POST, instance=food)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = FoodForm(instance=food)
    return render(request, 'fastfood_app/update_food.html', {'form': form})


# Taomni o'chirish
@permission_required('fastfood_app.delete_food')
def delete_food(request, pk):
    food = get_object_or_404(Food, pk=pk)
    food.delete()
    return redirect('home')
