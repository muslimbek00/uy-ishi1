from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView, CreateView, UpdateView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .models import Topic, Comment
from django.urls import reverse_lazy
from django.contrib.auth.models import User
from .models import Profile
from forum.models import Comment
class TopicListView(ListView):
    model = Topic
    template_name = 'forum/topic_list.html'


class TopicDetailView(DetailView):
    model = Topic
    template_name = 'forum/topic_detail.html'



class TopicUpdateView(UpdateView):
    model = Topic
    fields = ['title', 'content']
    template_name = 'forum/topic_form.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['action'] = 'Tahrirlash'
        return context

class TopicCreateView(CreateView):
    model = Topic
    fields = ['title', 'content']
    template_name = 'forum/topic_form.html'

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['action'] = 'Yaratish'
        return context


@login_required
def add_comment(request, pk):
    topic = Topic.objects.get(pk=pk)
    if request.method == 'POST':
        content = request.POST.get('content')
        Comment.objects.create(topic=topic, content=content, created_by=request.user)
        return redirect('topic-detail', pk=pk)
    return render(request, 'forum/add_comment.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})





def profile_view(request, username):
    user = get_object_or_404(User, username=username)
    profile = user.profile
    comments = Comment.objects.filter(user=user)  # Foydalanuvchi qoldirgan sharhlar

    context = {
        'user': user,
        'profile': profile,
        'comments': comments,
    }
    return render(request, 'your_app/profile.html', context)