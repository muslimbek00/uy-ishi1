from django.contrib import admin
from .models import FoodType, Food

admin.site.register(FoodType)
admin.site.register(Food)
