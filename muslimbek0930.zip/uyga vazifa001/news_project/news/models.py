
from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name


class Article(models.Model):
    title = models.CharField(max_length=200)  # Sarlavha
    content = models.TextField()  # Tarkib
    published_date = models.DateTimeField(auto_now_add=True)  # Chop etilgan sana
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='articles')  # Kategoriya
    author = models.CharField(max_length=100)  # Muallif

    def __str__(self):
        return self.title


class Comment(models.Model):
    article = models.ForeignKey(Article, on_delete=models.CASCADE, related_name='comments')  # Maqola
    username = models.CharField(max_length=100)  # Foydalanuvchi nomi
    email = models.EmailField()  # Elektron pochta
    text = models.TextField()  # Sharh matni
    published_date = models.DateTimeField(auto_now_add=True)  # Chop etilgan sana

    def __str__(self):
        return f"Comment by {self.username} on {self.article.title}"
