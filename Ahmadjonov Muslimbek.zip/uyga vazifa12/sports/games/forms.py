from django import forms
from .models import SportType, Game

class SportTypeForm(forms.ModelForm):
    class Meta:
        model = SportType
        fields = ['name', 'description']

class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['sport_type', 'date', 'location']
