from django.shortcuts import render, redirect

# Create your views here.

from .forms import SportTypeForm, GameForm

def add_sport_type(request):
    if request.method == 'POST':
        form = SportTypeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_sport_type')
    else:
        form = SportTypeForm()
    return render(request, 'games/add_sport_type.html', {'form': form})

def add_game(request):
    if request.method == 'POST':
        form = GameForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_game')
    else:
        form = GameForm()
    return render(request, 'games/add_game.html', {'form': form})
