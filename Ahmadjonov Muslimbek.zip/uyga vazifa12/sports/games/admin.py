from django.contrib import admin

# Register your models here.
from .models import SportType, Game

class GameAdmin(admin.ModelAdmin):
    list_display = ('sport_type', 'location', 'date')

admin.site.register(SportType)
admin.site.register(Game, GameAdmin)
