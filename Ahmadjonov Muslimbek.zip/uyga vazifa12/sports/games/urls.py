from django.urls import path
from . import views

urlpatterns = [
    path('add-sport/', views.add_sport_type, name='add_sport_type'),
    path('add-game/', views.add_game, name='add_game'),
]
