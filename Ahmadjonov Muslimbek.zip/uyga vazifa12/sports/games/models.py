

from django.db import models

class SportType(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name


class Game(models.Model):
    sport_type = models.ForeignKey(SportType, on_delete=models.CASCADE)
    date = models.DateField()
    location = models.CharField(max_length=200)

    def __str__(self):
        return f'{self.sport_type.name} - {self.location} on {self.date}'
