
from django.contrib.auth import views as auth_views
from django.urls import path
from . import views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.register, name='register'),
    path('', views.TopicListView.as_view(), name='topic-list'),
    path('topic/create/', views.TopicCreateView.as_view(), name='topic-create'),
    path('topic/<int:pk>/', views.TopicDetailView.as_view(), name='topic-detail'),
    path('topic/<int:pk>/update/', views.TopicUpdateView.as_view(), name='topic-update'),
    path('topic/<int:pk>/comment/', views.add_comment, name='add-comment'),
]

