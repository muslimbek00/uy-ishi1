from django.contrib import admin
from .models import Topic, Comment

admin.site.register(Topic)
admin.site.register(Comment)
