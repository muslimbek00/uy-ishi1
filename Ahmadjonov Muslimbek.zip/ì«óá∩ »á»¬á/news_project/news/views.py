from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Category, News

def index(request):
    categories = Category.objects.all()
    news_list = News.objects.all()
    return render(request, 'news/index.html', {'categories': categories, 'news_list': news_list})

def news_by_category(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    news_list = News.objects.filter(category=category)
    return render(request, 'news/news_by_category.html', {'category': category, 'news_list': news_list})

def news_detail(request, news_id):
    news = get_object_or_404(News, pk=news_id)
    return render(request, 'news/news_detail.html', {'news': news})
